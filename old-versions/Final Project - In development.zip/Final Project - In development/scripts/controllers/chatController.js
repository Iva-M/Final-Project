class ChatController {
        constructor(chatView, requester, baseUrl, appKey){
        this._chatView = chatView;
        this._requester = requester;
        this._appKey = appKey;
        this._baseServiceUrl = baseUrl + '/appdata/' + appKey + '/chat_entries/'
    };
    
    showChatPage() {
        this._chatView.showChatPage();
        let _that = this;
        
        let chatEntries = [];
        
        let requestUrl = this._baseServiceUrl;
        
        this._requester.get(requestUrl, 
            function success(data) {
            
                let currentId = 1;
            
                for (let i = 0; i < data.length && i < 20; i++) {
                    data[i].entryId = currentId;
                    currentId++;
                    chatEntries.push(data[i]);
                }
            
                _that._chatViewView.showChatPage(chatEntries, data);
            
            }, 
            function error(data) {
                showPopup('error', "Error loading chat!");
            }
        );
        
    };
    
    
}