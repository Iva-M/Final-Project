class ChatView {
    constructor(wrapperSelector, mainContentSelector){
        this._wrapperSelector = wrapperSelector;
        this._mainContentSelector = mainContentSelector;
    }
    
    
    showChatPage(sideBarData, mainData){
        let _that = this;
        $.get('templates/welcome-guest.html', function (template) {
            let renderedWrapper = Mustache.render(template, null);
            $(_that._wrapperSelector).html(renderedWrapper);


            $.get('templates/chat.html', function (template) {
                let chatEntries = {
                    chatEntries: mainData
                };

                let renderedPosts = Mustache.render(template, chatEntries);
                $('.articles').html(renderedPosts);
            })
        });
    }
    
    
    
}