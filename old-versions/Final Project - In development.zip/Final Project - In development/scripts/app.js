(function () {

    let baseUrl = "https://baas.kinvey.com";
    let appKey = "kid_ByObcIBo";
    let appSecret = "baf09e0f463140dfa0c96559575530a3";
    var _guestCredentials = "fd72c78c-b124-4866-b6f0-fe6ff53d9673.6BsQ7FFLc0azs3Xamh/XjNKzgRjlNs8gGiO93PXZ3cI=";
    
    let authService = new AuthorizationService(baseUrl, appKey, appSecret, _guestCredentials);
    
    authService.initAuthorizationType("Kinvey");
    
    let requester = new Requester(authService);
    
    let selector = ".wrapper";
    let mainContentSelector = ".main-content";

    let homeView = new HomeView(selector, mainContentSelector);
    let homeController = new HomeController(homeView, requester, baseUrl, appKey);

    let userView = new UserView(selector, mainContentSelector);
    let userController = new UserController(userView, requester, baseUrl, appKey);
    
    let postView = new PostView(selector, mainContentSelector);
    let postController = new PostController(postView, requester, baseUrl, appKey);
    
    let chatView = new ChatView(selector, mainContentSelector);
    let chatController = new ChatController(chatView, requester, baseUrl, appKey);

    initEventServices();

    onRoute("#/", function () {
        if (authService.isLoggedIn()){
            homeController.showUserPage();
        }
        else{
            homeController.showGuestPage();
        }
    });
    
    onRoute("#/post-:id", function () {
       let top = $("#post-" + this.params['id'])
           .position().top;
        $(window).scrollTop(top);
    });

    onRoute("#/login", function () {
        userController.showLoginPage(authService.isLoggedIn());
    });

    onRoute("#/register", function () {
        userController.showRegisterPage(authService.isLoggedIn());
    });

    onRoute("#/logout", function () {
        userController.logout();
    });

    onRoute('#/posts/create', function () {
        let data ={
            fullName: sessionStorage['fullName']
        }
        postController.showCreatePostPage(data, authService.isLoggedIn());
    });
    
    
    onRoute("#/chat", function () {
        userController.showChatPage(data);
     });    

    bindEventHandler('login', function (ev, data) {
        userController.login(data);
    });

    bindEventHandler('register', function (ev, data) {
        userController.register(data);
    });

    bindEventHandler('createPost', function (ev, data) {
        postController.createNewPost(data);
    });
    
    bindEventHandler('addEntry', function (ev, data) {
        //chatController.createNewPost(data);
    });

    run('#/');
})();
